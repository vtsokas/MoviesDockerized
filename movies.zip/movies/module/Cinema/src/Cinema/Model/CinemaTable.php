<?php
namespace Cinema\Model;

use Zend\Db\TableGateway\TableGateway;

class CinemaTable
{
    protected $tableGateway;
    protected $manager;
    protected $collection;

    public function __construct(TableGateway $tableGateway, \MongoDB\Driver\Manager $manager, $collection)
    {
        $this->tableGateway = $tableGateway;
        $this->manager =  $manager;
        $this->collection = $collection;
    }

    public function fetchAll($query = array())
    {
        // MySQL
        // $resultSet = $this->tableGateway->select($query);
        // return $resultSet;

        // MongoDB
        $query = new \MongoDB\Driver\Query($query);
        $cursor = $this->manager->executeQuery($this->collection, $query);
        $arr = $cursor->toArray();
        $res = array();
        foreach($arr as $it) {
            $it->id = $it->_id;
            $c = new Cinema();
            $c->exchangeArray(get_object_vars($it));
            $res[] = $c;
        }
        return $res;
    }

    public function getCinema($id)
    {
        // MySQL
        // $id  = (int) $id;
        // // We send the query parameters as an array
        // $rowset = $this->tableGateway->select(array('id' => $id));
        // $row = $rowset->current();
        // if (!$row) {
        //     throw new \Exception("Could not find row $id");
        // }
        // return $row;

        // MongoDB
        $row = $this->fetchAll(array('_id' => new \MongoDB\BSON\ObjectId($id)))[0];

        return $row;
    }

    public function saveCinema(Cinema $cinema)
    {     
        // Get data as array
        $data = array(
            'ownerId'  => $cinema->ownerId,
            'name' => $cinema->name
        );
        // Decide whether to add or update
        $id = $cinema->id;
        if ($id == 0) {
            // MySQL
            // $this->tableGateway->insert($data);

            // MongoDB
            $bulk = new \MongoDB\Driver\BulkWrite;
            $_id1 = $bulk->insert($data);
            $result = $this->manager->executeBulkWrite($this->collection, $bulk);
        } else {
            // MySQL
            // if ($this->getCinema($id)) {
            //     $this->tableGateway->update($data, array('id' => $id));
            // } else {
            //     throw new \Exception('Cinema id does not exist');
            // }

            // MongoDB
            $bulk = new \MongoDB\Driver\BulkWrite;
            $_id1 = $bulk->update(array('_id' => new \MongoDB\BSON\ObjectId($cinema->id)), $data);
            $result = $this->manager->executeBulkWrite($this->collection, $bulk);
        }
    }

    public function deleteCinema($id)
    {
        // MySQL
        // $this->tableGateway->delete(array('id' => (int) $id));

        // MongoDB
        $bulk = new \MongoDB\Driver\BulkWrite;
        $_id1 = $bulk->delete(array('_id' => new \MongoDB\BSON\ObjectId($id)));
        $result = $this->manager->executeBulkWrite($this->collection, $bulk);
    }
}