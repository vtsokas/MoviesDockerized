<?php
namespace Cinema\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Cinema\Model\CinemaTable;
use Cinema\Model\Cinema;
use User\Model\UserTable;

class CinemaRestController extends AbstractRestfulController
{
    protected $table;
    protected $userService;

    public function __construct(CinemaTable $table, UserTable $userTable)
    {
        $this->table = $table;
        $this->userService = $userTable;
    }

    public function getList()
    {   // Action used for GET requests without resource Id
        $query = array();
        if ($this->userService->getUserRole() == 'cinema_owner')
        {
            $query = array('ownerId' => $this->userService->getUserId());
        }

        $users = $this->userService->fetchAllAsOptions();

        $cinemas = $this->table->fetchAll($query);
        $response = array();

        foreach($cinemas as $cinema) {
            $cinema->id = (string)$cinema->id;
            foreach($users as $user) {
                if ($user['key'] == (string)$cinema->ownerId) {
                    $cinema->ownerName = $user['value'];
                    break;
                }
            }

            $response[] = $cinema;
        }
        return new JsonModel(
            $response
        );
    }

    public function get($id)
    {   // Action used for GET requests with resource Id
        $this->table->fetchAll(array('id' => $id));
    }

    public function create($data)
    {   // Action used for POST requests
        $cinema = new Cinema();
        $cinema->exchangeArray($data);
        $this->table->saveCinema($cinema);
        return new JsonModel(array('message' => 'Created'));
    }

    public function update($id, $data)
    {   // Action used for PUT requests
        $cinema = new Cinema();
        $cinema->exchangeArray($data);
        $cinema->id = $id;
        $this->table->saveCinema($cinema);
        return new JsonModel(array('message' => 'Updated'));
    }

    public function delete($id)
    {   // Action used for DELETE requests
        $this->table->deleteCinema($id);
        return new JsonModel(array('message' => 'Deleted'));
    }
}