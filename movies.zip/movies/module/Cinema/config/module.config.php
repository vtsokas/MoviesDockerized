<?php

namespace Cinema;

return array(
    // 'controllers' => array(
    //     'factories' => [
    //         src\module\Cinema\Controller\CinemaController::class => function($container) {
    //             return new Controller\CinemaController(
    //                 $container->get('Cinema\Model\CinemaTable')
    //             );
    //         },
    //     ],
    //     // 'invokables' => array(
    //     //     'Cinema\Controller\Cinema' => function($container) {
    //     //         return new Cinema\Controller\CinemaController(
    //     //             $container->get('Cinema\Model\CinemaTable')
    //     //         );
    //     //     },
    //     // ),
        
    // ),
    

    'router' => array(
        'routes' => array(
            'cinema' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/cinema[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => Controller\CinemaController::class,//'Cinema\Controller\Cinema',
                        'action'     => 'index',
                    ),
                ),
            ),
            'cinema-rest' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/cinema-rest[/:id]',
                    'constraints' => array(
                        'id'     => '[a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => Controller\CinemaRestController::class,
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'cinema' => __DIR__ . '/../view',
        ),
        'strategies' => array(
            'ViewJsonStrategy'
        )
    ),
);