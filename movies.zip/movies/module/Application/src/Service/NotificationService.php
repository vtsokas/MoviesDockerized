<?php

namespace Application\Service;

use User\Model\UserTable;
use Movie\Model\FavouriteTable;
use Movie\Model\Movie;

class NotificationService 
{
    protected $orionURL;
    protected $userTable;
    protected $favouriteTable;
    protected $manager;

    public function __construct(string $orionURL, UserTable $userTable, 
        FavouriteTable $favouriteTable, \MongoDB\Driver\Manager $manager)
    {
        $this->orionURL = $orionURL;
        $this->userTable = $userTable;
        $this->favouriteTable = $favouriteTable;
        $this->manager = $manager;
    }

    // Creates a notification for each user having the movie as favourite
    public function movieUpdated(Movie $movie) 
    {
        // Get users having the movie as favourite
        $favourites = $this->favouriteTable->fetchAll(array('movieId' => (string)$movie->id));
        $notifyUserIds = array();
        foreach($favourites as $favourite)
        {
            $notifyUserIds[] = (string)$favourite->userId;
        }
        // All users
        $users = $this->userTable->fetchAll();
        // Add a notification
        foreach($users as $user)
        {
            if (in_array((string)$user->id, $notifyUserIds))
            {
                $notifications = $user->notifications;
                if (!is_array($notifications)) $notifications = array();
                $notifications[] = $movie->title . ' at ' . $movie->cinemaName . ' from ' . $movie->startDate . ' to ' . $movie->endDate;
                $user->notifications = $notifications;
                $this->userTable->saveUser($user);
            }
        }
    }

    public function orionMovieCreated(Movie $movie)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'http://172.28.1.8:1027/v2/entities',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>'{
        "id": "' . (string)$movie->id . '",
        "type": "Movie",
        "startDate": {
            "value": "' . $movie->startDate . '",
            "type": "Date"
        },
        "endDate": {
            "value": "' . $movie->endDate . '",
            "type": "Date"
        }
        }',
        CURLOPT_HTTPHEADER => array(
                'X-Auth-Token: pass',
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
    }

    public function orionMovieUpdated(Movie $movie) 
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'http://172.28.1.8:1027/v2/entities/' . (string)$movie->id . '/attrs',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'PATCH',
        CURLOPT_POSTFIELDS =>'{
        "startDate": {
            "value": "' . $movie->startDate . '",
            "type": "Date"
        },
        "endDate": {
            "value": "' . $movie->endDate . '",
            "type": "Date"
        }
        }',
        CURLOPT_HTTPHEADER => array(
            'X-Auth-Token: pass',
            'Content-Type: application/json'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
    }
}