<?php
/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Model\UserTable;
use User\Model\User;

class IndexController extends AbstractActionController
{
    protected $manager;
    protected $dbname;
    protected $userTable;

    public function __construct(UserTable $userTable, \MongoDB\Driver\Manager $manager, $dbname)
    {
        $this->userTable = $userTable;
        $this->manager = $manager;
        $this->dbname = $dbname;
    }

    public function indexAction()
    {
        return new ViewModel();
    }

    public function initAction() 
    {
        $query = new \MongoDB\Driver\Query(array("username" => "admin@email.com"));
        $cursor = $this->manager->executeQuery('tuc_cinema.users', $query);
        $arr = $cursor->toArray();
        if (sizeof($arr) == 0) {

            $user = new User;

            $user->id = 0;
            $user->username = "admin@email.com";
            $user->email = "admin@email.com";
            $user->password = "pass";
            $user->role = "admin";
            $user->name = "Admin";

            $this->userTable->saveUser($user, true);
        }
        else 
        {
            echo '<br> - Id: ' . $this->userTable->getUserId();
            echo '<br> - Name: ' . $this->userTable->getUserInfo();
            echo '<br> - Role: ' . $this->userTable->getUserRole();
            echo '<br> - Token: ' . $this->userTable->getAccessToken();
        }

        return new ViewModel();
    }
}
