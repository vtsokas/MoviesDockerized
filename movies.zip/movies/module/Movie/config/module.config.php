<?php

namespace Movie;

return array(
    // 'controllers' => array(
    //     'factories' => [
    //         src\module\Movie\Controller\MovieController::class => function($container) {
    //             return new Controller\MovieController(
    //                 $container->get('Movie\Model\MovieTable')
    //             );
    //         },
    //     ],
    //     // 'invokables' => array(
    //     //     'Movie\Controller\Movie' => function($container) {
    //     //         return new Movie\Controller\MovieController(
    //     //             $container->get('Movie\Model\MovieTable')
    //     //         );
    //     //     },
    //     // ),
        
    // ),
    

    'router' => array(
        'routes' => array(
            'movie' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/movie[/:action][/:id][/:redirect]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[a-zA-Z0-9_-]*',
                        'redirect' => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => Controller\MovieController::class,//'Movie\Controller\Movie',
                        'action'     => 'index',
                    ),
                ),
            ),
            'movie-rest' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/movie-rest[/:id]',
                    'constraints' => array(
                        'id'     => '[a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => Controller\MovieRestController::class,
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'movie' => __DIR__ . '/../view',
        ),
        'strategies' => array(
            'ViewJsonStrategy'
        )
    ),
);