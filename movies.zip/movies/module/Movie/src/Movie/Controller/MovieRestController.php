<?php
namespace Movie\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Movie\Model\MovieTable;
use Movie\Model\Movie;
use Movie\Model\FavouriteTable;
use Movie\Model\Favourite;
use User\Model\UserTable;
use Cinema\Model\CinemaTable;

class MovieRestController extends AbstractRestfulController
{
    protected $table;
    protected $userService;
    protected $favouriteTable;
    protected $cinemaTable;

    public function __construct(MovieTable $table, UserTable $userTable, FavouriteTable $favouriteTable, CinemaTable $cinemaTable)
    {
        $this->table = $table;
        $this->userService = $userTable;
        $this->favouriteTable = $favouriteTable;
        $this->cinemaTable = $cinemaTable;
    }

    public function getList()
    {   // Action used for GET requests without resource Id
        $favourites = $this->favouriteTable->getFavouriteMovieIds(array('userId' => $this->userService->getUserId()));
        $movies = $this->table->fetchAll(array());
        $response = array();

        // var_dump($favourites);
        foreach($movies as $movie) {
            // var_dump($movie->id);
            $movie->favourite = (in_array((string)$movie->id, $favourites) > 0);
            $movie->id = (string)$movie->id;
            $response[] = $movie;
        }

        // If cinema owner, get his/hers cinemas and filter the movies
        $query = array();
        if ($this->userService->getUserRole() == 'cinema_owner')
        {
            $cinemas = $this->cinemaTable->fetchAll(
                array('ownerId' => $this->userService->getUserId()));

            $arr = array();
            foreach ($cinemas as $cinema) 
            {
                $arr[] = $cinema->name;
            }

            // $query = array('cinemaName' => $arr);
            $mtemp = array();
            foreach($movies as $movie)
            {
                if (in_array($movie->cinemaName, $arr))
                {
                    $mtemp[] = $movie;
                }
            }

            $response = $mtemp;
        }

        return new JsonModel(
            $response
        );
    }

    public function get($id)
    {   // Action used for GET requests with resource Id
        $this->table->fetchAll(array('id' => $id));
    }

    public function create($data)
    {   // Action used for POST requests
        $movie = new Movie();
        $movie->exchangeArray($data);
        $this->table->saveMovie($movie);
        return new JsonModel(array('message' => 'Created'));
    }

    public function update($id, $data)
    {   // Action used for PUT requests
        $movie = new Movie();
        $movie->exchangeArray($data);
        $movie->id = $id;
        $this->table->saveMovie($movie);
        return new JsonModel(array('message' => 'Updated'));
    }

    public function delete($id)
    {   // Action used for DELETE requests
        $this->table->deleteMovie($id);
        return new JsonModel(array('message' => 'Deleted'));
    }

}