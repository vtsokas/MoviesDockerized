<?php
namespace Movie\Model;

use Zend\Db\TableGateway\TableGateway;

class MovieTable
{
    protected $tableGateway;
    protected $manager;
    protected $collection;

    public function __construct(TableGateway $tableGateway, \MongoDB\Driver\Manager $manager, $collection)
    {
        $this->tableGateway = $tableGateway;
        $this->manager =  $manager;
        $this->collection = $collection;
    }

    public function fetchAll($query = array())
    {
        // MySQL
        // $resultSet = $this->tableGateway->select($query);
        // return $resultSet;

        // MongoDB
        $query = new \MongoDB\Driver\Query($query);
        $cursor = $this->manager->executeQuery($this->collection, $query);
        $arr = $cursor->toArray();
        $res = array();
        foreach($arr as $movie) {
            $movie->id = $movie->_id;
            $m = new Movie();
            $m->exchangeArray(get_object_vars($movie));
            $res[] = $m;
        }
        return $res;
    }

    public function getMovie($id)
    {
        // MySQL
        // $id  = (int) $id;
        // // We send the query parameters as an array
        // $rowset = $this->tableGateway->select(array('id' => $id));
        // $row = $rowset->current();
        // if (!$row) {
        //     throw new \Exception("Could not find row $id");
        // }

        // MongoDB
        $row = $this->fetchAll(array('_id' => new \MongoDB\BSON\ObjectId($id)))[0];

        return $row;
    }

    public function saveMovie(Movie $movie)
    {     
        // Get data as array
        $data = array(
            'title'  => $movie->title,
            'startDate' => $movie->startDate,
            'endDate'  => $movie->endDate,
            'cinemaName' => $movie->cinemaName,
            'category'  => $movie->category
        );
        // Decide whether to add or update
        $id = (int) $movie->id;
        if ($id == 0) {
            // MySQL
            // $this->tableGateway->insert($data);

            // MongoDB
            $bulk = new \MongoDB\Driver\BulkWrite;
            $_id1 = $bulk->insert($data);
            $result = $this->manager->executeBulkWrite($this->collection, $bulk);
        } else {
            // MySQL
            // if ($this->getMovie($id)) {
            //     $this->tableGateway->update($data, array('id' => $id));
            // } else {
            //     throw new \Exception('Movie id does not exist');
            // }

            // MongoDB
            $bulk = new \MongoDB\Driver\BulkWrite;
            $_id1 = $bulk->update(array('_id' => new \MongoDB\BSON\ObjectId($movie->id)), $data);
            $result = $this->manager->executeBulkWrite($this->collection, $bulk);
        }

        return (string)$_id1;
    }

    public function deleteMovie($id)
    {
        // MySQL
        //$this->tableGateway->delete(array('id' => (int) $id));

        // MongoDB
        $bulk = new \MongoDB\Driver\BulkWrite;
        $_id1 = $bulk->delete(array('_id' => new \MongoDB\BSON\ObjectId($id)));
        $result = $this->manager->executeBulkWrite($this->collection, $bulk);
    }
}