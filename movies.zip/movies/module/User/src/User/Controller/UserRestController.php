<?php
namespace User\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use User\Model\UserTable;
use User\Model\User;

class UserRestController extends AbstractRestfulController
{
    protected $table;

    public function __construct(UserTable $table)
    {
        $this->table = $table;
    }

    public function getList()
    {   // Action used for GET requests without resource Id

        // Authorize the user. Redirect to login if not authorized
        if (!$this->table->isAllowed('user_view'))
        {
            return new JsonModel(array('message' => 'Unauthorized action'));
        }

        $query = array();
        $users = $this->table->fetchAll($query);

        $response = array();

        foreach($users as $user) {
            $user->id = (string)$user->id;
            $response[] = $user;
        }

        return new JsonModel(
            $response
        );
    }

    public function get($id)
    {   // Action used for GET requests with resource Id

        // Authorize the user. Redirect to login if not authorized
        if (!$this->table->isAllowed('user_view'))
        {
            return new JsonModel(array('message' => 'Unauthorized action'));
        }

        if ($id == 'current') 
        {
            $user = $this->table->getUser($this->table->getUserId());
            $user->id = (string)$user->id;
            $user->password = null;
            return new JsonModel(
                $user->getArrayCopy()
            );
        }

        return new JsonModel(
            $this->table->fetchAll(array('id' => $id))
        );
    }

    public function create($data)
    {   // Action used for POST requests

        // Authorize the user. Redirect to login if not authorized
        if (!$this->table->isAllowed('user_add'))
        {
            return new JsonModel(array('message' => 'Unauthorized action'));
        }

        $user = new User();
        $user->exchangeArray($data);
        $this->table->saveUser($user);
        return new JsonModel(array('message' => 'Created'));
    }

    public function update($id, $data)
    {   // Action used for PUT requests

        // Authorize the user. Redirect to login if not authorized
        if (!$this->table->isAllowed('user_edit'))
        {
            return new JsonModel(array('message' => 'Unauthorized action'));
        }

        $user = new User();
        $user->exchangeArray($data);
        $user->id = $id;
        // Modify the object, save and return
        if ($user->password == null)
        {
            $user->password = $this->table->getUser($id)->password;
            $this->table->saveUser($user);
        } else 
        {
            $this->table->saveUser($user, true);
        }
        $this->table->saveUser($user);
        return new JsonModel(array('message' => 'Updated'));
    }

    public function delete($id)
    {   // Action used for DELETE requests

        // Authorize the user. Redirect to login if not authorized
        if (!$this->table->isAllowed('user_delete'))
        {
            return new JsonModel(array('message' => 'Unauthorized action'));
        }

        $this->table->deleteUser($id);
        return new JsonModel(array('message' => 'Deleted'));
    }
}