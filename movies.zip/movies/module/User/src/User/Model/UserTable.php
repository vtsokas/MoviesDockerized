<?php
namespace User\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Session\Container;

class UserTable
{
    protected $tableGateway;
    protected $manager;
    protected $sessionContainer;
    protected $collection;

    protected $permissions = array(
        'admin' => array('*'),
        'unauthorized' => array('user_add'),
        'cinema_owner' => array('user_edit',
            'movie_view', 'movie_add', 'movie_edit', 'movie_delete', 
            'cinema_view', 'cinema_add', 'cinema_edit', 'cinema_delete',
            'movie_favourite'),
        'user' => array('movie_view', 'user_add', 'user_edit','movie_favourite')
    );

    public function __construct(TableGateway $tableGateway, Container $sessionContainer, \MongoDB\Driver\Manager $manager, $collection)
    {
        $this->tableGateway = $tableGateway;
        $this->sessionContainer = $sessionContainer;
        $this->manager =  $manager;
        $this->collection = $collection;
    }

    /////////////
    // A U T H //
    /////////////

    public function login($username, $password) 
    {
        // Keryrock
        $access_token = $this->keyrockLogin($username, $password);

        $password = hash('md5', $password);
        $q = array(
            'username' => $username, 
            'password' => $password
        );
        // MongoDB
        $query = new \MongoDB\Driver\Query($q);
        $cursor = $this->manager->executeQuery($this->collection, $query);
        $arr = $cursor->toArray();
        $row = $arr[0];

        if ($row != null) {
            $this->sessionContainer->userId = (string)$row->_id;
            $this->sessionContainer->username = $username;
            $this->sessionContainer->password = $password;
            $this->sessionContainer->role = $row->role;
            $this->sessionContainer->token = $access_token;
        } else {
            $this->sessionContainer->role = 'unauthorized';
        }
    }

    public function logout() 
    {
        $this->sessionContainer->userId = null;
        $this->sessionContainer->username = null;
        $this->sessionContainer->password = null;
        $this->sessionContainer->role = 'unauthorized';
        $this->sessionContainer->token = null;
    }

    public function getUserRole() 
    {
        return $this->sessionContainer->role;
    }

    public function getUserInfo()
    {
        return $this->sessionContainer->username;
    }

    public function getUserId()
    {
        return $this->sessionContainer->userId;
    }

    public function getAccessToken()
    {
        return $this->sessionContainer->token;
    }
    
    public function isAllowed($resource) 
    {
        if ($this->getUserRole() == null) $this->sessionContainer->role = 'unauthorized';
        $permissions = $this->permissions[$this->getUserRole()];
        if (in_array('*', $permissions) || in_array($resource, $permissions)) 
        {
            return true;
        }

        return false;
    }

    /////////////
    // KEYROCK //
    /////////////

    // Returns Subject Token
    public function keyrockLoginSuperAdmin() 
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'http://172.28.1.3:3000/v1/auth/tokens',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_HEADER => 1,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>'{
        "name": "superadmin@email.com",
        "password": "pass"
        }',
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Cookie: _csrf=9E8K2WV7KDsE9OFhSRlUeHm7; session=eyJyZWRpciI6Ii8ifQ==; session.sig=TqcHvLKCvDVxuMk5xVfrKEP-GSQ'
        ),
        ));

        $response = curl_exec($curl);
        
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $header = substr($response, 0, $header_size);

        curl_close($curl);

        return $this->get_string_between($header, "X-Subject-Token: ", " Content-Type");
    }

    // Returns Access Token - OAuth2
    public function keyrockLogin($username, $password)
    {
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://172.28.1.3:3000/oauth2/token',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => 'grant_type=password&username=' . $username . '&password=' . $password,
          CURLOPT_HTTPHEADER => array(
            'Authorization: Basic OTRmMjg2MjEtNzQ2OS00ZTdiLWIyNTAtYzM0N2FhMjVkOWJhOjQ4NTdlZGI0LTA5ZDQtNDdkMS05NjU4LTVhOGNhNTI3ZWYxNA==',
            'Content-Type: application/x-www-form-urlencoded',
            'Cookie: _csrf=9E8K2WV7KDsE9OFhSRlUeHm7; session=eyJyZWRpciI6Ii8ifQ==; session.sig=TqcHvLKCvDVxuMk5xVfrKEP-GSQ'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);

        return $this->get_string_between($response, '"access_token":"', '"');
    }

    public function keyrockCreateUser($username, $email, $password, $subject_token)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://172.28.1.3:3000/v1/users',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'',
          CURLOPT_POSTFIELDS =>'{
            "user" : {
                "username": "' . $username . '",
                "email": "' . $email . '",
                "password": "' . $password . '"
            }
        }',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'X-Auth-token: ' . $subject_token,
            'Cookie: _csrf=9E8K2WV7KDsE9OFhSRlUeHm7; session=eyJyZWRpciI6Ii8ifQ==; session.sig=TqcHvLKCvDVxuMk5xVfrKEP-GSQ'
          ),
        ));

        $response = curl_exec($curl);

        // echo 'Keyrock: ' . $username . ' ' . $email . ' ' . $password . ' ' . $subject_token; 
        // echo $response;
        curl_close($curl);
    }

    /////////////
    // C R U D //
    /////////////

    public function fetchAll($query = array())
    {
        // MySQL
        // $resultSet = $this->tableGateway->select();
        // return $resultSet;

        // MongoDB
        $query = new \MongoDB\Driver\Query($query);
        $cursor = $this->manager->executeQuery($this->collection, $query);
        $arr = $cursor->toArray();
        $res = array();
        foreach($arr as $it) {
            $it->id = $it->_id;
            $c = new User();
            $c->exchangeArray(get_object_vars($it));
            $res[] = $c;
        }
        return $res;
    }

    public function fetchAllAsOptions()
    {
        $resultSet = $this->fetchAll();
        $options = array();
        foreach ($resultSet as $row) 
        {
            $options[] = array("key" => $row->id, "value" => $row->username);
        }
        return $options;
    }

    public function getUser($id)
    {
        // MySQL
        // $id  = (int) $id;
        // $rowset = $this->tableGateway->select(array('id' => $id));
        // $row = $rowset->current();
        // if (!$row) {
        //     throw new \Exception("Could not find row $id");
        // }
        // return $row;

        // MongoDB
        $row = $this->fetchAll(array('_id' => new \MongoDB\BSON\ObjectId($id)))[0];

        return $row;
    }

    public function saveUser(User $user, $hashPassword = false)
    {     
        $password = ($hashPassword == true) ? hash('md5', $user->password) : $user->password;
        $data = array(
            'name'  => $user->name,
            'surname' => $user->surname,
            'username'  => $user->username,
            'password' => $password,
            'email'  => $user->email,
            'role' => $user->role,
            'isConfirmed'  => $user->isConfirmed
        );

        $id = $user->id;
        if ($id == 0) {
            // MySQL
            // $this->tableGateway->insert($data);

            // MongoDB
            $bulk = new \MongoDB\Driver\BulkWrite;
            $_id1 = $bulk->insert($data);
            $result = $this->manager->executeBulkWrite($this->collection, $bulk);

            // Keyrock
            $this->keyrockCreateUser($user->username, $user->email, $user->password, $this->keyrockLoginSuperAdmin());
        } else {
            // MySQL
            // if ($this->getUser($id)) {
            //     $this->tableGateway->update($data, array('id' => $id));
            // } else {
            //     throw new \Exception('User id does not exist');
            // }

            // MongoDB
            $bulk = new \MongoDB\Driver\BulkWrite;
            $_id1 = $bulk->update(array('_id' => new \MongoDB\BSON\ObjectId($user->id)), $data);
            $result = $this->manager->executeBulkWrite($this->collection, $bulk);
        }
    }

    public function deleteUser($id)
    {
        // MySQL
        $this->tableGateway->delete(array('id' => (int) $id));

        // MongoDB
        $bulk = new \MongoDB\Driver\BulkWrite;
        $_id1 = $bulk->delete(array('_id' => new \MongoDB\BSON\ObjectId($id)));
        $result = $this->manager->executeBulkWrite($this->collection, $bulk);
    }

    // Helper method
    public function get_string_between($string, $start, $end){
        $string = " ".$string;
        $ini = strpos($string,$start);
        if ($ini == 0) return "";
        $ini += strlen($start);   
        $len = strpos($string,$end,$ini) - $ini;
        return substr($string,$ini,$len);
    }
}